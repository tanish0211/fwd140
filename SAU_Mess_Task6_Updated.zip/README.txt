SAU MESS - TASK 6 UPDATED PROJECT

Files:
- index.html: original home page + new FAQ section
- events.html: original weekly menu + CSS-only food category filters + print instructions
- registration.html: original file, unchanged
- contact.html: original file, unchanged
- style.css: original CSS preserved; Task-6 CSS appended at the end

NEW FEATURES:
1. CSS-only vegetarian/non-vegetarian menu filters.
2. FAQ section using native HTML details/summary (no JavaScript).
3. Print-friendly weekly menu using @media print.

HOW TO TEST:
1. Extract this ZIP into a folder.
2. Open index.html in a browser.
3. Open Weekly Food Menu and test all three filter labels.
4. Press Ctrl+P (Windows) or Cmd+P (Mac) to preview printing.
5. Open Home and expand/collapse the FAQ questions.

IMPORTANT:
- No JavaScript is used.
- The original registration and contact pages are unchanged.
- The original CSS content is retained; new CSS is appended.
- The print action uses the browser's built-in print command because HTML/CSS alone
  cannot trigger the print dialog with a clickable button.
